//
//  main.cpp
//  Act4.3
//
//  Created by Emma Gomez  on 04/12/20.
//

#include <string>
#include <fstream>
#include <sstream>
#include <queue>
#include <list>
#include <string>
#include <vector>
#include <stack>
#include <stdlib.h>
#include <cstdlib>
#include <iostream>
using namespace std;

#include "Graph.h"
#include "Heap.h"
#include "Info.h"


int main() {
    //Leer el archivo por linea
    fstream archivoEntrada;
    cout << "Leyendo el archivo de entrada... " << endl;
    archivoEntrada.open("bitacoraACT4_3.txt", ios::in);
    cout << "El archivo 'bitacoreACT4_3.txt' se cargó correctamente..."<< endl << endl;
    
    string linea, source, target;
    
    vector< vector<string> > list;
    vector<string> listIPs;
    int pos;
    int n = 0;
    int cont = 0; // se iría leyendo linea por linea
    while(getline(archivoEntrada,linea)){
        stringstream s(linea);
        if(cont==0){
            pos = (int)linea.find(" ");
            n = stoi(linea.substr(0,pos+1));
        }
        if(cont<=n){
            listIPs.push_back(linea); //almacena los ips existentes
        }
        if(cont>n){
            vector<string> listIPsT;
            //busca el primer espacio
            pos = (int)linea.find(" ");
            linea.erase(0,pos+1);
            pos = (int)linea.find(" ");
            linea.erase(0,pos+1);
            pos = (int)linea.find(" ");
            linea.erase(0,pos+1);
            pos = (int)linea.find(":");
            listIPsT.push_back(linea.substr(0,pos));
            linea.erase(0,pos+1);
            pos = (int)linea.find(" ");
            linea.erase(0,pos+1);
            pos = (int)linea.find(":");
            listIPsT.push_back(linea.substr(0,pos));
            linea.erase(0,pos+1);
            list.push_back(listIPsT);
        }
        cont++;
    }
    archivoEntrada.close();
    Graph<string> grafo(list, listIPs);
    //grafo.print();
    grafo.maxIP();
    
    return 0;
}

