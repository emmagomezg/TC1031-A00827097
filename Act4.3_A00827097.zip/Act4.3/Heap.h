//
//  Heap.h
//  Act4.3
//
//  Created by Emma Gomez  on 05/12/20.
//

#ifndef Heap_h
#define Heap_h

#include "DoublyLinkedList.h"
#include "IPs.h"

#include "DoublyLinkedList.h"
#include "IPs.h"

template <class T>
class Heap {
private:
    DoublyLinkedList<T> heap;
    int size;
    void downSort(int index);
    void swap(int a, int b);
    void upSort();
public:
    Heap();
    Heap(DoublyLinkedList<T>);
    T remove();
    T& operator[](int index);
    int getSize();
    void insert(T data);
    bool isEmpty();
    void print();
};

template <class T>
Heap<T>::Heap(){
    size = 0;
}

template <class T>
int Heap<T>::getSize(){
    return size;
}

template <class T>
T& Heap<T>::operator[](int index){
    return heap[index];
}

template <class T>
void Heap<T>::swap(int a, int b){
    T aux = heap[a];
    heap[a] = heap[b];
    heap[b] = aux;
}

template <class T>
void Heap<T>::downSort(int index){
    while (index >= 1){
        int pos = index;
        while (pos * 2 <= size){
            int s1 = pos * 2;
            int s2 = (pos * 2) + 1;
            int max;
            if (s2 > size) {
                max = s1;
            } else {
                IPs aux1 = heap[s1];
                IPs aux2 = heap[s2];
                aux1.cant > aux2.cant ? max = s1 : max = s2;
            }
            IPs aux01 = heap[max];
            IPs aux02 = heap[pos];
            if (aux01.cant > aux02.cant){
                swap(pos, max);
                pos = max;
            } else {
                pos = size;
            }
        } index--;
    }
}

template <class T>
Heap<T>::Heap(DoublyLinkedList<T> list){
    if (!list.isEmpty()){
        heap = list;
        size = heap.getSize();
        int index = size / 2;
        downSort(index);
    } else {
        size = 0;
    }
}

template <class T>
T Heap<T>::remove(){
    if (!isEmpty()){
        T aux = heap[1];
        swap(1,size);
        heap.deleteLast();
        size--;
        downSort(1);
        return aux;
    }
    throw runtime_error("ERROR: Heap is empty.");
}

template <class T>
void Heap<T>::upSort(){
    int pos = size;
    while (pos > 1){
        int father = pos / 2;
        IPs aux1 = heap[pos];
        IPs aux2 = heap[father];
        if (aux1.cant > aux2.cant){
            swap(father, pos);
            pos = father;
        } else {
            pos = 1;
        }
    }
}

template <class T>
void Heap<T>::insert(T data) {
    heap.addLast(data);
    size++;
    upSort();
}

template <class T>
bool Heap<T>::isEmpty(){
    return size == 0;
}

template <class T>
void Heap<T>::print(){
    heap.print();
}

#endif /* Heap_h */
