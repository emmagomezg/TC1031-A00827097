//
//  IPs.h
//  Act4.3
//
//  Created by Emma Gomez  on 05/12/20.
//

#pragma once

struct IPs {
    string ipAd;
    int cant;
    IPs();
    IPs(string ipAd);
    IPs(string ipAd, int n);
    void addCant();
    void print();
};

IPs::IPs(){
    cant = 0;
}

IPs::IPs(string ip){
    ipAd = ip;
    cant++;
}

IPs::IPs(string ip, int n){
    ipAd = ip;
    cant = n;
}

void IPs::addCant(){
    cant++;
}

void IPs::print(){
    cout << ipAd << "       "  << cant << endl;
}

