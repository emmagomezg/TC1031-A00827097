//
//  Graph.h
//  Act4.3
//
//  Created by Emma Gomez  on 04/12/20.
//

#ifndef Graph_h
#define Graph_h

#include "Heap.h"
#include "IPs.h"

template <class T>
class Graph{
private:
    vector< vector<T> > adjList;
    vector<T> vertices;
    int qtyVertices;
    int qtyEdges;
    int findVertex(T vertex);
    //void shortestPath(T vertex);
public:
    Graph(vector< vector<T> > lista, vector<T> listIPs);
    void print();
    void maxIP();
};

template <class T>
Graph<T>::Graph(vector< vector<T> > list, vector<T> listIPs) {
    vertices = listIPs;
    int source = 0;
    int target = 1;
    
    sort(vertices.begin(), vertices.end());
    vector< vector<T> > tempList(vertices.size());
    adjList = tempList; 
    //adyacencias
    for (auto edge : list){
        int posSource = findVertex(edge[source]);
        adjList[posSource].push_back(edge[target]);
    }
}

template <class T>
int Graph<T>::findVertex(T vertex){
    typename vector<T>::iterator it;
    it = find(vertices.begin(), vertices.end(), vertex);
    if (it != vertices.end())
        return it - vertices.begin();
    else
        return -1;
}

template <class T>
void Graph<T>::maxIP(){
    DoublyLinkedList<IPs> ip;
    for(int i = 0; i<vertices.size(); i++){
        IPs ips;
        ips.ipAd = vertices[i];
        ips.cant = adjList[i].size();
        ip.addLast(ips);
    }
    Heap<IPs> heap(ip);
    
    cout << "Se obtuvieron los IPs más cargados y su cantidad." << endl << endl << "El IP con más adyacencias es: " << endl;
    //el remove obtiene el mayor de la lista y lo imprime con el metodo de imprimir
    IPs maxIP = heap.remove();
    maxIP.print();
}

/*
template <class T>
void Graph<T>::shortestPath(T vertex){
    vector<bool> known(vertices.size(), false);
    vector<int> weight(vertices.size(), INT_MAX);
    vector<int> path(vertices.size(), -1);
    stack<int> pathStack;
    vector< stack<int> > pathS(vertices.size(), pathStack);
    
    int pos = findVertex(vertex);
    if (pos >= 0) {
        weight[pos] = 0;
        int minVertex = findMin(weight, known);
        while (minVertex >= 0) {
            known[minVertex] = true;
            for (auto adj : adjList[minVertex]) {
                int posAdj = findVertex(adj.target);
                if (!known[posAdj]){
                    if (weight[posAdj] > weight[minVertex] + adj.weight){
                        weight[posAdj] = weight[minVertex] + adj.weight;
                        path[posAdj] = minVertex;
                    }
                }
            }
            minVertex = findMin(weight, known);
        }
        
        for (int v = 0; v < vertices.size(); v++){
            pathS[v].push(v);
            int nextVertex = v; // currentPath o nextVertex
            while (path[nextVertex] >= 0){
                pathS[v].push(path[nextVertex]);
                nextVertex = path[nextVertex];
            }
        }
        
        for(int v = 0; v < vertices.size(); v++) {
            cout << "Path: ";
            while (!pathS[v].empty()){
                cout << pathS[v].top() << " ";
                pathS[v].pop();
            }
            cout << "\t"<< "\t" << "\t" <<  "Weight: " << weight[v] << endl;
        }
    }
}
*/
 
template <class T>
void Graph<T>::print(){
    for (auto vertexAdj : adjList){
        for (auto vertex : vertexAdj){
            cout << vertex << " ";
        }
        cout << endl;
    }
}

#endif /* Graph_h */
