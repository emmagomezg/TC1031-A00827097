//
//  IPs.h
//  Act3.4
//
//  Created by Emma Gomez  on 24/10/20.
//

#include <string>
#include <iostream>
using namespace std;

#pragma once

struct IPs{
    int cant;
    string ipAd;
    IPs();
    IPs(int cant, string ipAd);
    string imprimir();
    bool operator>(IPs);
};

IPs::IPs(){
    ipAd = "";
    cant = 0;
}

IPs::IPs(int cant, string ipAd){
    this -> cant = cant;
    this -> ipAd = ipAd;
}

string IPs :: imprimir(){
    return ipAd + " cantidad existente: " + to_string(cant);
}

bool IPs :: operator>(IPs info){
    return this->cant > info.cant;
}
