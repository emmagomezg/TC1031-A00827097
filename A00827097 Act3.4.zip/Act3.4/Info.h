//
//  Info.h
//  Act3.4
//
//  Created by Emma Gomez  on 23/10/20.
//

#pragma once
#include <iostream>
#include <string>

struct Info{
    string dateTime;
    string ipPuerto;
    string error;
    string imprimir();
    bool operator>(Info);
    Info(string dateTime, string ipPuerto, string error);
    Info();
};

Info :: Info(){
    dateTime = " ";
    ipPuerto = " ";
    error = " ";
}

Info :: Info(string dateTime, string ipPuerto, string error){
    this -> dateTime = dateTime;
    this -> ipPuerto = ipPuerto;
    this -> error = error;
}

string Info :: imprimir(){
    return dateTime + " " + ipPuerto + " " + error;
}

bool Info :: operator>(Info info){
    return this->ipPuerto > info.ipPuerto;
}
