//
//  main.cpp
//  Act3.4
//
//  Created by Emma Gomez  on 23/10/20.
//

#include <string>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <stdlib.h>
#include <cstdlib>
#include <iostream>
using namespace std;

#include "Heap.h"
#include "Info.h"
#include "IPs.h"


template<class T>
void HeapSort(DoublyLinkedList<T>& list, string order = "ascending"){
    if(!list.isEmpty()){
        Heap<T> heapAux(list);
        list.clear();
        while(!heapAux.isEmpty()){
            if(order == "ascending"){
                list.addFirst(heapAux.remove());
            }
            else{
                list.addLast(heapAux.remove());
            }
        }
    }
}


int main(int argc, const char * argv[]) {
    
    //Leer el archivo por linea
    fstream archivoEntrada;
    archivoEntrada.open("bitacora2.txt", ios::in);
    cout << "El archivo 'bitacore2.txt' se cargó correctamente..."<< endl << endl;
    
    //Queue para ir almazenando cada dato de la lista
    string linea, mes, fecha, hora, ipPuerto, dateTime, error, m, h, min, seg, fechaHora;
    int pos;
    DoublyLinkedList<Info> informacion;
    //Queue <string> bitacora;
    while(getline(archivoEntrada,linea)){
        stringstream s(linea);
        //mes string -> entero
        pos = (int)linea.find(":");
        dateTime = linea.substr(0,pos+1);
        linea.erase(0,pos + 1);
        //Oct 9 10:
        //se almacena lo restante del dateTime
        pos = (int)linea.find(" ");
        dateTime = dateTime + linea.substr(0,pos+1);
        linea.erase(0,pos + 1);
        //Oct 9 10:32:24
            
        //IP
        pos = (int)linea.find(":");
        ipPuerto = linea.substr(0,pos); //se eliminan los espacios
        linea.erase(0,pos + 1);
        
        //Error
        pos = (int)linea.find(" ");
        linea.erase(0,pos + 1);
        error = linea;
        //parte el error de la linea
        
        //se crea un objeto con los parametros y se almacena en el vector
        informacion.addLast(Info(dateTime,ipPuerto,error));
        //bitacora.enqueue(linea);
    }
    
    archivoEntrada.close();
    HeapSort(informacion);
    cout << "El archivo se ordenó correctamente..."<< endl << endl;
    
    // TOP 5
    
    DoublyLinkedList<IPs> list;
    string anterior;
    int cantidad;
    anterior = informacion[1].ipPuerto;
    int i = 1;
    while(i<=informacion.getSize()-1){ //mientras que sea menor al tamaño del archivo
        cantidad = 0;
        int j = i;
        while(informacion[j].ipPuerto == anterior && j<=informacion.getSize()-1){
            //se compara con el valor anterior. el 1 se compara consigo mismo. se checa que si son iguales la cantidad se aumenta, sino se sale del ciclo
            cantidad++;
            anterior = informacion[j].ipPuerto;
            j++;
        }
        /*cout << i << endl;
        cout << j << endl;
        cout << cantidad << endl;*/
        // se almacena
        list.addLast(IPs(cantidad,anterior));
        i += cantidad;
        anterior = informacion[j].ipPuerto;
    }
    
    Heap<IPs> heap(list);
    
    cout << "Se obtuvieron los IPs más cargados y su cantidad." << endl << endl << "El top 5 de IPs son: " << endl << endl;
    //el remove obtiene el mayor de la lista y lo imprime con el metodo de imprimir
    cout << "1. " << heap.remove().imprimir() << endl;
    cout << "2. " << heap.remove().imprimir() << endl;
    cout << "3. " << heap.remove().imprimir() << endl;
    cout << "4. " << heap.remove().imprimir() << endl;
    cout << "5. " << heap.remove().imprimir() << endl << endl;
    
    return 0;
}
