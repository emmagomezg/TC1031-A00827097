//
//  Graph.h
//  Act5.2
//
//  Created by Emma Gomez  on 06/12/20.
//

#ifndef Graph_h
#define Graph_h

template <class T>
class Graph{
private:
    vector< vector<T> > adjList;
    Hash hash;
    int qtyVertices;
    int qtyEdges;
    int findVertex(T vertex);
    //void shortestPath(T vertex);
public:
    Graph(vector< vector<T> > lista, vector<T> listIPs);
    void print();
    void ipAdj(string ip);
};

template <class T>
Graph<T>::Graph(vector< vector<T> > list, vector<T> listIPs) {
    int source = 0;
    int target = 1;
    
    Hash hashtable(listIPs.size(), listIPs);
    hash = hashtable;
    
    vector< vector<T> > tempList(listIPs.size());
    adjList = tempList; 
    //adyacencias
    for (auto edge : list){
        int posSource = findVertex(edge[source]);
        adjList[posSource].push_back(edge[target]);
    }
}

template <class T>
int Graph<T>::findVertex(T vertex){
    int key = hash.hashing(vertex);
    int hashing = key;
    while(hash.table[key]!=vertex){
        if(key!=13369){
            key++;
        }
        else{
            key = 0;
        }
        if(key==hashing){
            return -1;
        }
    }
    return key;
}


/*
template <class T>
void Graph<T>::shortestPath(T vertex){
    vector<bool> known(vertices.size(), false);
    vector<int> weight(vertices.size(), INT_MAX);
    vector<int> path(vertices.size(), -1);
    stack<int> pathStack;
    vector< stack<int> > pathS(vertices.size(), pathStack);
    
    int pos = findVertex(vertex);
    if (pos >= 0) {
        weight[pos] = 0;
        int minVertex = findMin(weight, known);
        while (minVertex >= 0) {
            known[minVertex] = true;
            for (auto adj : adjList[minVertex]) {
                int posAdj = findVertex(adj.target);
                if (!known[posAdj]){
                    if (weight[posAdj] > weight[minVertex] + adj.weight){
                        weight[posAdj] = weight[minVertex] + adj.weight;
                        path[posAdj] = minVertex;
                    }
                }
            }
            minVertex = findMin(weight, known);
        }
        
        for (int v = 0; v < vertices.size(); v++){
            pathS[v].push(v);
            int nextVertex = v; // currentPath o nextVertex
            while (path[nextVertex] >= 0){
                pathS[v].push(path[nextVertex]);
                nextVertex = path[nextVertex];
            }
        }
        
        for(int v = 0; v < vertices.size(); v++) {
            cout << "Path: ";
            while (!pathS[v].empty()){
                cout << pathS[v].top() << " ";
                pathS[v].pop();
            }
            cout << "\t"<< "\t" << "\t" <<  "Weight: " << weight[v] << endl;
        }
    }
}
*/
 
template <class T>
void Graph<T>::print(){
    for (auto vertexAdj : adjList){
        for (auto vertex : vertexAdj){
            cout << vertex << " ";
        }
        cout << endl;
    }
}

template<class T>
void Graph<T>::ipAdj(string ip){
    int key = findVertex(ip);
    for (auto vertex : adjList[key]){
        cout << vertex << " ";
    }
}


#endif /* Graph_h */
