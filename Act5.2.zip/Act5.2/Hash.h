//
//  Hash.h
//  Act5.2
//
//  Created by Emma Gomez  on 06/12/20.
//

#ifndef Hash_h
#define Hash_h

#include <vector>

struct Hash{
    vector<string> table;
    vector<int> status;
    int size;
    int qty;
    int hashing(string str);
    bool isFull();
    Hash();
    Hash(int size,vector<string> list);
    void addStr(string str);
    void print();
};

Hash::Hash() {
    size = 0;
    qty = 0;
    vector<string> tempList;
    vector<int> tempStatus;
    table = tempList;
    status = tempStatus;
}

Hash::Hash(int size,vector<string> list) {
    qty = 0;
    this->size = size;
    vector<string> tempList(size);
    vector<int> tempStatus(size,0);
    status = tempStatus;
    table = tempList;
    for (auto str : list) {
        addStr(str);
    }
}

//Str sería el IP
void Hash::addStr(string str){
    if (!isFull()){
        int index = hashing(str);
        if (status[index]!=1){
            table[index] = str;
            status[index]=1;
            qty++;
        }
        else{
            while(status[index]==1){
                if(index!=13369){
                    index++;
                }
                else{
                    index=0;
                }
            }
            table[index] = str;
            status[index] = 1;
            qty++;
        }
    }
}

int Hash::hashing(string strIP) {
    int pos;
    string ips;
    int key;
    pos = (int)strIP.find(".");
    ips = strIP.substr(0,pos);
    strIP.erase(0,pos+1);
    pos = (int)strIP.find(".");
    strIP.erase(0,pos+1);
    pos = (int)strIP.find(".");
    strIP.erase(0,pos+1);
    ips += strIP;
    key = stoi(ips);
    //se suma el primero y el ultimo
    //ej. 78.89.221.25
    // se suma el 78 y el 25
    // se obtiene el residuo de 7825 % 13370 (size)
    return key % size;
}

bool Hash::isFull() {
    return qty == size;
}

void Hash::print() {
    cout << "Hash Table" << endl;
    for(int i=0; i<size; i++) {
        cout << " " << "i" << "|" << table[i]<< endl;
    }
    cout << endl;
}
#endif

