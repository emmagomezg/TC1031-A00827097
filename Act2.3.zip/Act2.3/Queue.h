//
//  Queue.h
//  Act2.3
//
//  Created by Emma Gomez  on 07/10/20.
//

#ifndef Queue_h
#define Queue_h

#include "Node.h"
using namespace std;

template <class T>
class Queue {
private:
    Node<T>* Front;
    Node<T>* end;
    int size;
    
public:
    Queue();
    T dequeue();
    void enqueue(T d);
    T front();
    T back();
    int getSize();
    T getData(int pos);
    void clear();
    void print();
};

template <class T>
Queue<T>::Queue(){
    Front = NULL;
    end = NULL;
    size = 0;
}

template <class T>
T Queue<T>::dequeue(){
    T dat;
    if (Front != NULL) {
        Node<T>* aux = Front;
        dat = Front -> data;
        Front = Front -> next;
        if (Front == NULL) {
            end = NULL;
        }
        delete(aux);
        size--;
        return dat;
    } else {
        throw runtime_error("ERROR: LA LISTA ESTA VACIA");
    }
}

template <class T>
void Queue<T>::enqueue(T d){
    Node<T>* aux = new Node<T>(d, Front);
    if (end == NULL) {
        Front = end = aux;
        size++;
        return;
    }
    size++;
    end -> next = aux;
    end = aux;
    
}

template <class T>
T Queue<T>::front(){
    return Front -> data;
}

template <class T>
T Queue<T>::back(){
    return end -> data;
}

template <class T>
int Queue<T>::getSize(){
    return size;
}

template<class T>
T Queue<T>::getData(int pos){
    if(pos >= 1 && pos <= size){
        Node<T>* aux = Front;
        for(int i=1; i<pos; i++){
            aux = aux->next;
        }
        return aux -> data;
    }
    
    throw runtime_error("OUT OF RANGE");
}

template <class T>
void Queue<T>::clear(){
    if (size > 0) {
        int i = 0;
        while (i < size){
            Node<T>* aux = Front;
            Front = Front -> next;
            delete(aux);
            i++;
        }
        size = 0;
    } else {
        throw runtime_error("ERROR: LA LISTA ESTA VACIA");
    }
}

template <class T>
void Queue<T>::print(){
    if (size == 0) {
        cout << "Queue is empty." << endl;
    } else {
        Node<T>* aux = Front;
        for (int i = 0; i < size; i++) {
            cout << aux -> data << " ";
            aux = aux -> next;
        }
        cout << endl;
    }
}

#endif /* Queue_h */
