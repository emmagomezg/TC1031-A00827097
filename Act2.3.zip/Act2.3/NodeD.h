//
//  NodeD.h
//  Act2.3
//
//  Created by Emma Gomez  on 06/10/20.
//

#pragma once
#include <iostream>

//Nodo Doubly Linked List

template <class T>
struct NodeD{
    NodeD(T data);
    NodeD(T data, NodeD<T>* next, NodeD<T>* prev);
    T data;
    NodeD<T>* prev;
    NodeD<T>* next;
};

template <class T>
NodeD<T>::NodeD(T data){
    this -> data = data;
    this -> next = NULL;
    this -> prev = NULL;
}

template <class T>
NodeD<T>::NodeD(T data, NodeD<T>* next, NodeD<T>* prev){
    this -> data = data;
    this -> next = next;
    this -> prev = prev;
}
