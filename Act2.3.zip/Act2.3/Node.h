//
//  Node.h
//  Act2.3
//
//  Created by Emma Gomez  on 05/10/20.
//

#pragma once
#include <iostream>

//Nodo Queue
//similar al de Linked Lists, solo apunta a NEXT
template <class T>
struct Node{
    Node(T data);
    Node(T data, Node<T>* next);
    T data;
    Node<T>* next;
};

template <class T>
Node<T>::Node(T data){
    this -> data = data;
    this -> next = NULL;
}

template <class T>
Node<T>::Node(T data, Node<T>* next){
    this -> data = data;
    this -> next = next;
}
