//
//  DoublyLinkedList.h
//  Act2.3
//
//  Created by Emma Gomez  on 05/10/20.
//

#ifndef DoublyLinkedList_h
#define DoublyLinkedList_h

#include "NodeD.h"
#include "Queue.h"
#include "Info.h"
using namespace std;

template <class T>
class DoublyLinkedList{
private:
    NodeD<T>* head;
    NodeD<T>* tail;
    int size;
public:
    DoublyLinkedList();
    void addLast(T data);
    T getData(int pos);
    void updateAt(int pos, T data);
    void sort();
    void merge(int inicio, int medio, int fin);
    void mergeSort(int inicio, int fin);
    int getSize();
    int findData(int dateTime2, bool inicio); //binary search
    //
    bool isEmpty();
    void print();
};

//Constructor
template <class T>
DoublyLinkedList<T>::DoublyLinkedList(){
    head = NULL;
    tail = NULL;
    size = 0;
}

template<class T>
void DoublyLinkedList<T>::addLast(T data){
    if (!isEmpty()){
        tail->next = new NodeD<T>(data,NULL,tail);
        tail = tail->next;
    }
    else {
        head = new NodeD<T>(data);
        tail = head;
    }
    size++;
}

template<class T>
T DoublyLinkedList<T>::getData(int pos){
    if(pos >= 1 && pos <= size){
        NodeD<T>* aux = head;
        for(int i=1; i<pos; i++){
            aux = aux->next;
        }
        return aux -> data;
    }
    
    throw runtime_error("OUT OF RANGE");
}

template<class T>
void DoublyLinkedList<T>::updateAt(int pos, T data){
    if(pos >= 1 && pos <= size){
        NodeD<T>* aux = head;
        for(int i=1; i<pos; i++){
            aux = aux->next;
        }
        aux -> data = data;
    }
    else{
        throw runtime_error("OUT OF RANGE");
    }
}

template<class T>
void DoublyLinkedList<T>::merge(int inicio, int medio, int fin){
    Queue<Info> left;
    Queue<Info> right;
    
    int pos = inicio;
    int tamI = (medio - inicio) + 1;
    int tamD = fin - medio;
    
    for (int i = 1; i <= tamI; i++) {
        left.enqueue(getData(inicio + i-1));
    }
    
    for (int j = 1; j <= tamD; j++) {
        right.enqueue(getData(medio + j + 1 - 1));
    }
    
    int i = 1;
    int j = 1;
    
    while (i <= tamI && j <= tamD) {
        if (left.getData(i).dateTime <= right.getData(j).dateTime){
            updateAt(pos, left.getData(i));
            i++;
        }
        else {
            updateAt(pos, right.getData(j));
            j++;
        }
        pos++;
    }
    
    while (i <= tamI){
        updateAt(pos, left.getData(i));
        i++;
        pos++;
    }
    
    while (j <= tamD){
        updateAt(pos, right.getData(j));
        j++;
        pos++;
    }
}

template<class T>
void DoublyLinkedList<T>::mergeSort(int inicio, int fin){
    if (inicio < fin) {
        int medio = (inicio + fin) / 2;
        mergeSort(inicio, medio);
        mergeSort(medio + 1, fin);
        merge(inicio, medio, fin);
    }
}

template<class T>
void DoublyLinkedList<T>::sort(){
    mergeSort(1, size);
}

template <class T>
int DoublyLinkedList<T>::getSize(){
    return size;
}

template <class T>
int DoublyLinkedList<T>::findData (int dateTime2, bool inicio){
    //Busqueda Binaria
    int inf = 1;
    int sup = size;
    while ((inf <= sup)){
        int mid = (inf + sup) / 2;
        //si buscamos el primer valor del rango
        if (inicio){
            if ((getData(mid).dateTime >= dateTime2) && (getData(mid-1).dateTime < dateTime2)){
                return mid;
            }
            //se encuentra del lado derecho
            else if(getData(mid).dateTime < dateTime2){
                inf = mid + 1;
            }
            //se encuentra del lado izquierdo
            else{
                sup = mid - 1;
            }
        }
        //si buscamos el ultimo valor que entra en el rango
        else {
            if ((getData(mid).dateTime <= dateTime2) && (getData(mid+1).dateTime > dateTime2)){
                return mid;
            }
            //se encuentra del lado derecho
            else if(getData(mid).dateTime < dateTime2){
                inf = mid + 1;
            }
            //se encuentra del lado izquierdo
            else{
                sup = mid - 1;
            }
        }
    }
    return -1;
}

//

template <class T>
void DoublyLinkedList<T>::print(){
    NodeD<T>* aux = head;
    for(int i=0; i<size; i++){
        cout<< aux -> data << " ";
        aux = aux -> next;
    }
    cout << endl;
}

template <class T>
bool DoublyLinkedList<T>::isEmpty(){
    return size == 0;
}

#endif /* DoublyLinkedList_h */
