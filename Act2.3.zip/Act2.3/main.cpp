//
//  main.cpp
//  Act2.3
//
//  Created by Emma Gomez  on 05/10/20.
//

#include <string>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <vector>
#include <stdlib.h>
#include <cstdlib>
#include <iostream>

#include "DoublyLinkedList.h"
#include "Info.h"

using namespace std;


/*
 
I N S T R U C C I O N E S :
 
 1. Ordene la información por fecha y hora para la realización de las búsquedas.
    - Utiliza el método Sort de tu Doubly Linked List
    - El método sort deberá de ser Merge Sort o Quick Sort
    - El método sort deberá de usar Queue o Stack
 
 2. Solicite al usuario las fecha y hora de inicio y fin de búsqueda de información.
    - Utiliza uno el algoritmos de búsqueda binario para encontrar el rango inicial y el rango final.
 
 3. Despliegue los registros correspondientes a esas fechas.
 
 4. Almacenar en un archivo el resultado del ordenamiento.
 
 */

int main() {
    //Leer el archivo por linea
    fstream archivoEntrada;
    archivoEntrada.open("bitacora.txt", ios::in);
    
    //Queue para ir almazenando cada dato de la lista
    string linea, mes, fecha, hora, ipError, m, d, h, min, seg, fechaHora;
    int pos, dia, dateTime;
    string meses[] = {"","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    DoublyLinkedList<Info> informacion;
    //Queue <string> bitacora;
    while(getline(archivoEntrada,linea)){
        stringstream s(linea);
        //mes string -> entero
        pos = (int)linea.find(" ");
        m = linea.substr(0,pos);
        linea.erase(0,pos + 1);
    
        for (int i=1;i<=12;i++){ //para convertir el mes en numero (Jan = 01)
            if (m == meses[i]){
                mes = to_string(i); //se convierte a string
            }
        }
         
        //Dia
        pos = (int)linea.find(" ");
        d = linea.substr(0,pos); //se eliminan los espacios
        linea.erase(0,pos + 1);
        dia = std::stoi(d);
        //para que los meses enero, febrero, marzo, junio, julio, agosto y septiembre aparezcan con doble digito
        // de esta manera: 01,02,03,04,05,06,07,08,09
        if (dia<=9){
            d= "0" + d; //si es de enero a septiembre se cumple
        }
        
        //MMDD con enteros
        fecha = mes + d; // para juntar el mes y el dia ej: 0914 (sept 14)
            
        //Hora
        pos = (int)linea.find(":"); //se eliminan los dos puntos despues de la hora
        h = linea.substr(0,pos);
        linea.erase(0,pos + 1);
            
        //Minutos
        pos = (int)linea.find(":"); //se eliminan los dos puntos despues de los minutos
        min = linea.substr(0,pos);
        linea.erase(0,pos + 1);
            
        //Segundos
        pos = (int)linea.find(" "); //se eliminan los dos puntos despues de los segundos
        seg = linea.substr(0,pos);
        linea.erase(0,pos + 1);
            
        //Tiempo
        hora = h + min + seg;
        fechaHora = fecha + hora;
        dateTime = std::stoi(fechaHora);
            
        //IP Error
        ipError = linea;
        //se crea un objeto con los parametros y se almacena en el vector
        informacion.addLast(Info(dateTime,ipError));
        //bitacora.enqueue(linea);
    }
    
    archivoEntrada.close();
    informacion.sort();
    
    ofstream archivoSalida("bitacora.Ordenada.txt");
    for (int i=1; i<informacion.getSize(); i++){
        archivoSalida << informacion.getData(i).imprimir() << endl;
    }
    archivoSalida.close();
    cout << "Se ha creado un archivo con los datos de forma ordenada" << endl;
    
    //Validación de INPUTS
    bool not_valid = true;
    int rangoInicial = 0;
    int rangoFinal = 0;
    string mess, diaa, horaa, day;
    bool mes_not_valid = true;
    while (not_valid){
        //datos de inicio de la búsqueda
        cout << "Teclea la fecha de inicio de tu búsqueda" << endl;
        
        while (mes_not_valid){
          cout << "Ingrese el mes (ej: Jan):";
          cin >> mes;
          
          string meses[] = {"","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
          for (int i=1; i<=12; i++){
            if (mes == meses[i]){ //valida si el mes ingresado está en la lista
              mes = to_string(i);
              mes_not_valid = false;
            }
          }
          if (mes_not_valid){ //si el mes ingresado no está en la lista
            cout << "El mes ingresado no es válido para este tipo de busca. Vuelva ingresar el mes." << endl;
          }
        }
        cout << "Ingrese el día (de 1-31): ";
        cin >> day;
        
        while (stoi(day)<=0 || stoi(day)>31){
          cout << "El dia ingresado no es válido para este tipo de busca. Vuelva ingresar el dia." << endl << "Día (de 1-31): ";
          cin >> day;
        }
          
        if (stoi(day)<=9){
          day = "0" + day;
        }
          
        cout << "Teclea la hora de inicio de tu búsqueda (de 0-23): ";
        cin >> hora;
          
        while (stoi(hora)<0 || stoi(hora)>23){
          cout << "La hora ingresada no es válida para este tipo de busca. Vuelva ingresar la hora." << endl << "Hora (de 0-23): ";
          cin >> hora;
        }
          
        if (stoi(hora)<=9){
          hora = "0" + hora;
        }
        
        //SEGUNDA PARTE
        //diaa --> dia 2 ingresado
        //mess --> mes 2 ingresado
        //horaa --> hora 2 ingresada
        
        cout << "Teclea la fecha final de tu búsqueda" << endl;
        mes_not_valid = true;
        while (mes_not_valid){
          cout << "Ingrese el mes (ej: Jan):: ";
          cin >> mess;
          //busca que el mes ingresado esté en la lista
          string meses[] = {"","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
          for (int i=1; i<=12; i++){
            if (mess == meses[i]){
              mess = to_string(i);
              mes_not_valid = false;
            }
          }
          if (mes_not_valid){
            cout << "El mes ingresado no es válido para este tipo de busca. Vuelva ingresar el mes." << endl;
          }
        }
          
        cout << "Ingrese el día (de 1-31): ";
        cin >> diaa;
          
        while (stoi(diaa)<=0 || stoi(diaa)>31){
          cout << "El dia ingresado no es válido para este tipo de busca. Vuelva ingresar el dia." << endl << "Día (de 1-31): ";
          cin >> diaa;
        }
          
        if (stoi(diaa)<=9){
          diaa = "0" + diaa;
        }
          
        cout << "Teclea la hora de final de tu búsqueda (0-23): ";
        cin >> horaa;
          
        while (stoi(horaa)<0 || stoi(horaa)>23){
          cout << "La hora ingresada no es válida para este tipo de busca. Vuelva ingresar la hora." << endl << "Hora (0-23): ";
          cin >> horaa;
        }
          
        if (stoi(horaa)<=9){
          horaa = "0" + horaa;
        }
          
        rangoInicial = std::stoi(mes + day + horaa + "00" + "00");
        rangoFinal = std::stoi(mess + diaa + horaa + "00" + "00");
        
        // se valida que la fecha inicial sea menor que la fecha final
        if (rangoInicial > rangoFinal){
          cout << "Tu búsqueda no es válida. La fecha y la hora inicial deben ser menores a la fecha y la hora final que se están buscando. Ingresar de nuevo los datos: " << endl;
          mes_not_valid = true;
        }
        else{
          not_valid = false;
        }
    }
    
    
    //BINARY SEARCH
    int posInicial = informacion.findData(rangoInicial, true);
    //elemento final
    int posFinal = informacion.findData(rangoFinal, false);
    //si no se encontraron los datos
    if (posInicial == -1 || posFinal == -1){
        cout << "No hay datos con ese rango en el archivo 'bitacora.txt'" << endl;
    }
    else{
        for (int i=posInicial; i<=posFinal; i++){
            cout << informacion.getData(i).imprimir() << endl;
        }
      }

    return 0;
}
