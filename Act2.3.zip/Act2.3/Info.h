//
//  Info.h
//  Act2.3
//
//  Created by Emma Gomez  on 07/10/20.
//

#pragma once
#include <iostream>
#include <string>

struct Info{
    //struct, como class pero sin public y private
    int dateTime;
    string ipError;
    Info(int,string);
    string imprimir();
    Info();
    
};

Info :: Info(){
    dateTime = 1;
    ipError = "ERROR";
}

Info :: Info(int dateTime, string ipError){
    this -> dateTime = dateTime;
    this -> ipError = ipError;
}

string Info :: imprimir(){
    string dateHour = to_string(dateTime);
    int size = dateHour.size()-1;
    string hora,min,seg;
    seg = dateHour.substr(size-1,2);
    min = dateHour.substr(size-3,2);
    hora = dateHour.substr(size-5,2);
    string mes,dia;
    dia = dateHour.substr(size-7,2);
   
    if (dia.substr(0,1) == "0"){
    dia = dia.substr(1,1);
    }
      if (size == 8){
        mes = dateHour.substr(size-8,1);
      }
      else{
        mes = dateHour.substr(size-9,2);
      }
      //regresar el mes a su string original
      //lista que contiene los meses
      string meses[] = {"","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
      mes = meses[stoi(mes)];
      return  mes + " " + dia + " " + hora + ":" + min + ":" + seg + " " + ipError;
}
